# build Chess Game Using HTML , CSS & JavaScript

<p align="center">
  <img src="ChessGame.jpg" width="500" height="320" />
</p>

## Demo
Watch the demo [here](https://youtu.be/ku0lcfbakXo?si=5wnGFKPSelprFi6M) 

### Need a Star for this Repository ⭐
